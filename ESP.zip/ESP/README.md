# ESP32 BLDC ESC Firmware

This folder contains the ESP32 firmware for the BLDC motor + ESC setup.

File:

- `ESP32_BLDC_ESC_Control.ino`

## What it does

- connects the ESP32 to Wi-Fi
- drives the ESC with a standard `50 Hz` servo-style control signal
- exposes:
  - `GET /motor/status`
  - `POST /motor/speed`
- returns the current commanded speed to the backend

## Before uploading

Update these values in the sketch:

- `WIFI_SSID`
- `WIFI_PASSWORD`
- `ESC_SIGNAL_PIN` if you want a different GPIO

## Wiring

- `ESP32 GND` -> `ESC GND`
- `ESP32 GPIO 18` -> `ESC signal`
- `ESC power` -> battery
- `BLDC motor` -> ESC motor wires

Do not power the motor from the ESP32.

## API example

### GET status

`GET http://<esp32-ip>/motor/status`

Response:

```json
{
  "currentSpeed": 20,
  "targetSpeed": 20,
  "online": true,
  "ip": "192.168.1.50",
  "uptimeMs": 12345
}
```

### POST speed

`POST http://<esp32-ip>/motor/speed`

Request body:

```json
{
  "speed": 35
}
```

## Notes

- The current sketch reports commanded speed, not real measured RPM.
- For real speed feedback, add a hall sensor or encoder and update `currentSpeed`.
- Keep the motor unloaded during the first ESC test.
- Most ESCs need a few seconds at minimum throttle to arm after power-up.
